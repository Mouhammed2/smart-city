create function st_rotatez(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Rotate($1, $2)$$;

alter function st_rotatez(geometry, double precision) owner to postgres;

