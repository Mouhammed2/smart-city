create function dropgeometrycolumn(table_name character varying, column_name character varying) returns text
    strict
    language plpgsql
as
$$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;

alter function dropgeometrycolumn(varchar, varchar) owner to postgres;

