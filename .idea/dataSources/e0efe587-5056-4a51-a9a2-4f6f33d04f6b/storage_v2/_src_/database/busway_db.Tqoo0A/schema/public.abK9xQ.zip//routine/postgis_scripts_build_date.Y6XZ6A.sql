create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2025-11-14 17:03:43'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

