create function st_isvalidreason(geometry, integer) returns text
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$
	SELECT CASE WHEN valid THEN 'Valid Geometry' ELSE reason END FROM (
		SELECT (public.ST_isValidDetail($1, $2)).*
	) foo
	$$;

alter function st_isvalidreason(geometry, integer) owner to postgres;

