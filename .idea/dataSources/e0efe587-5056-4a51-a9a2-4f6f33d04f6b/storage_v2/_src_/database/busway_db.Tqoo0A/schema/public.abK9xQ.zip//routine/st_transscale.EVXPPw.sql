create function st_transscale(geometry, double precision, double precision, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Affine($1,  $4, 0, 0,  0, $5, 0,
		0, 0, 1,  $2 * $4, $3 * $5, 0)$$;

alter function st_transscale(geometry, double precision, double precision, double precision, double precision) owner to postgres;

