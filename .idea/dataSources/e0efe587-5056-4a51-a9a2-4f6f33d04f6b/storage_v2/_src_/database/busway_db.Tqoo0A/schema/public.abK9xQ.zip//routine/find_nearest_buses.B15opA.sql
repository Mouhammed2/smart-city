create function find_nearest_buses(p_latitude double precision, p_longitude double precision, p_radius_meters double precision DEFAULT 1000, p_limit integer DEFAULT 5)
    returns TABLE(bus_id integer, bus_number character varying, distance_meters double precision, latitude double precision, longitude double precision, route_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT 
        b.id,
        b.bus_number,
        ST_Distance(
            ST_SetSRID(ST_MakePoint(p_longitude, p_latitude), 4326)::geography,
            b.current_location::geography
        ) as distance_meters,
        ST_Y(b.current_location::geometry) as latitude,
        ST_X(b.current_location::geometry) as longitude,
        r.name
    FROM buses b
    LEFT JOIN routes r ON b.route_id = r.id
    WHERE b.status = 'ACTIVE'
        AND b.current_location IS NOT NULL
        AND ST_DWithin(
            b.current_location::geography,
            ST_SetSRID(ST_MakePoint(p_longitude, p_latitude), 4326)::geography,
            p_radius_meters
        )
    ORDER BY distance_meters
    LIMIT p_limit;
END;
$$;

alter function find_nearest_buses(double precision, double precision, double precision, integer) owner to postgres;

